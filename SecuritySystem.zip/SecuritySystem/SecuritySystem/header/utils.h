/*
 * utils.h
 *
 * Created: 13-3-2019 11:14:06
 *  Author: Dion van der Linden
 */ 


#ifndef UTILS_H_
#define UTILS_H_

//#define F_CPU 8000000L
void Utils_Wait(int ms);


#endif /* UTILS_H_ */