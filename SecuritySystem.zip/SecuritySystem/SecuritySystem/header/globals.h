/*
 * globals.h
 *
 * Created: 17-Mar-19 14:01:21
 *  Author: Dion
 */ 


#ifndef GLOBALS_H_
#define GLOBALS_H_

#ifndef F_CPU
#define F_CPU 8000000L//8000000L
#endif

#endif /* GLOBALS_H_ */